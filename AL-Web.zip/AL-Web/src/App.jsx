import {
  BrowserRouter,
  Routes,
  Route,
  Navigate,
  NavLink,
  useParams,
} from "react-router-dom";

import { 
  useState 
} from "react";

import "./App.css";

const navigation = [
  { name: "Dashboard", path: "/", icon: "▦" },
  { name: "Applications", path: "/applications", icon: "▤" },
  { name: "AI Audit Console", path: "/ai-audit", icon: "◈" },
  { name: "Stress Testing", path: "/stress-testing", icon: "⌁" },
  { name: "Loan Approval", path: "/approval", icon: "✓" },
];


const applicationsData = [
  {
    id: "APP-2026-001",
    name: "James Murphy",
    property: "Residential",
    amount: "€285,000",
    status: "Under Review",
    risk: "Low",
  },
  {
    id: "APP-2026-002",
    name: "Sarah O'Brien",
    property: "First-Time Buyer",
    amount: "€320,000",
    status: "Pending",
    risk: "Medium",
  },
  {
    id: "APP-2026-003",
    name: "Daniel Walsh",
    property: "Residential",
    amount: "€410,000",
    status: "Approved",
    risk: "Low",
  },
  {
    id: "APP-2026-004",
    name: "Emma Kelly",
    property: "Buy-to-Let",
    amount: "€195,000",
    status: "Under Review",
    risk: "High",
  },
  {
    id: "APP-2026-005",
    name: "Michael Byrne",
    property: "First-Time Buyer",
    amount: "€265,000",
    status: "Pending",
    risk: "Medium",
  },
];



function Layout({ children }) {
  return (
    <div className="app-layout">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-icon">AL</div>
          <div>
            <h2>Agentic Lender</h2>
            <span>Multi-View Portal</span>
          </div>
        </div>

        <div className="nav-section">
          <p className="nav-label">WORKSPACE</p>

          {navigation.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              end={item.path === "/"}
              className={({ isActive }) =>
                isActive ? "nav-link active" : "nav-link"
              }
            >
              <span className="nav-icon">{item.icon}</span>
              {item.name}
            </NavLink>
          ))}
        </div>

        <div className="sidebar-footer">
          <div className="user-avatar">U</div>
          <div>
            <strong>Underwriter</strong>
            <span>Bank Officer</span>
          </div>
        </div>
      </aside>

      <main className="main-content">
        <header className="topbar">
          <div>
            <span className="breadcrumb">AL-WEB / WORKSPACE</span>
          </div>
          <div className="topbar-right">
            <span className="system-status">
              <span className="status-dot"></span>
              System Online
            </span>
            <div className="topbar-avatar">U</div>
          </div>
        </header>

        <div className="page-content">{children}</div>
      </main>
    </div>
  );
}


function Dashboard() {
  const stats = [
    {
      title: "Total Applications",
      value: "248",
      change: "+12.5%",
      description: "Compared to last month",
      icon: "▤",
      color: "blue",
    },
    {
      title: "Pending Reviews",
      value: "64",
      change: "26%",
      description: "Awaiting assessment",
      icon: "◷",
      color: "orange",
    },
    {
      title: "Approved Loans",
      value: "142",
      change: "+8.2%",
      description: "Successfully approved",
      icon: "✓",
      color: "green",
    },
    {
      title: "High Risk",
      value: "18",
      change: "7.3%",
      description: "Require further review",
      icon: "!",
      color: "red",
    },
  ];

  const applications = [
    {
      id: "APP-2026-001",
      name: "James Murphy",
      property: "Residential",
      amount: "€285,000",
      status: "Under Review",
      risk: "Low",
    },
    {
      id: "APP-2026-002",
      name: "Sarah O'Brien",
      property: "First-Time Buyer",
      amount: "€320,000",
      status: "Pending",
      risk: "Medium",
    },
    {
      id: "APP-2026-003",
      name: "Daniel Walsh",
      property: "Residential",
      amount: "€410,000",
      status: "Approved",
      risk: "Low",
    },
    {
      id: "APP-2026-004",
      name: "Emma Kelly",
      property: "Buy-to-Let",
      amount: "€195,000",
      status: "Under Review",
      risk: "High",
    },
    {
      id: "APP-2026-005",
      name: "Michael Byrne",
      property: "First-Time Buyer",
      amount: "€265,000",
      status: "Pending",
      risk: "Medium",
    },
  ];

  return (
    <Layout>
      <div className="dashboard-header">
        <div>
          <h1>Dashboard Overview</h1>
          <p>Welcome back, Underwriter. Here's your lending overview.</p>
        </div>
        <button className="primary-button">+ New Application</button>
      </div>

      <div className="stats-grid">
        {stats.map((stat) => (
          <div className="stat-card" key={stat.title}>
            <div className={`stat-icon ${stat.color}`}>
              {stat.icon}
            </div>
            <p>{stat.title}</p>
            <h2>{stat.value}</h2>
            <span className="stat-description">
              <strong>{stat.change}</strong> {stat.description}
            </span>
          </div>
        ))}
      </div>

      <div className="section-header">
        <div>
          <h2>Recent Applications</h2>
          <p>Monitor the latest mortgage applications.</p>
        </div>
        <NavLink to="/applications" className="view-all">
          View all →
        </NavLink>
      </div>

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>APPLICATION ID</th>
              <th>APPLICANT</th>
              <th>TYPE</th>
              <th>LOAN AMOUNT</th>
              <th>STATUS</th>
              <th>RISK LEVEL</th>
              <th>ACTION</th>
            </tr>
          </thead>

          <tbody>
            {applicationsData.map((app) => (
              <tr key={app.id}>
                <td className="application-id">{app.id}</td>
                <td>{app.name}</td>
                <td>{app.property}</td>
                <td className="amount">{app.amount}</td>

                <td>
                  <span className={`status-badge ${app.status.toLowerCase().replace(" ", "-")}`}>
                    {app.status}
                  </span>
                </td>

                <td>
                  <span className={`risk-badge ${app.risk.toLowerCase()}`}>
                    {app.risk}
                  </span>
                </td>

                <td>
                  <NavLink to={`/applications/${app.id}`} className="detail-link">
                    View →
                  </NavLink>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Layout>
  );
}


function Applications() {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  const [riskFilter, setRiskFilter] = useState("All");

  const filteredApplications = applicationsData.filter((app) => {
    const matchesSearch =
      app.name.toLowerCase().includes(search.toLowerCase()) ||
      app.id.toLowerCase().includes(search.toLowerCase());

    const matchesStatus =
      statusFilter === "All" || app.status === statusFilter;

    const matchesRisk =
      riskFilter === "All" || app.risk === riskFilter;

    return matchesSearch && matchesStatus && matchesRisk;
  });

  function clearFilters() {
    setSearch("");
    setStatusFilter("All");
    setRiskFilter("All");
  }

  return (
    <Layout>
      <div className="applications-header">
        <div>
          <h1>Loan Applications</h1>
          <p>Manage and monitor mortgage applications.</p>
        </div>

        <button className="primary-button">
          + New Application
        </button>
      </div>

      <div className="applications-summary">
        <div>
          <span>Total Applications</span>
          <strong>{applicationsData.length}</strong>
        </div>
        <div>
          <span>Pending</span>
          <strong>
            {applicationsData.filter(app => app.status === "Pending").length}
          </strong>
        </div>
        <div>
          <span>Under Review</span>
          <strong>
            {applicationsData.filter(app => app.status === "Under Review").length}
          </strong>
        </div>
        <div>
          <span>Approved</span>
          <strong>
            {applicationsData.filter(app => app.status === "Approved").length}
          </strong>
        </div>
      </div>

      <div className="application-filters">
        <input
          type="text"
          placeholder="Search by applicant or application ID..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />

        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
        >
          <option value="All">All Statuses</option>
          <option value="Pending">Pending</option>
          <option value="Under Review">Under Review</option>
          <option value="Approved">Approved</option>
        </select>

        <select
          value={riskFilter}
          onChange={(e) => setRiskFilter(e.target.value)}
        >
          <option value="All">All Risk Levels</option>
          <option value="Low">Low Risk</option>
          <option value="Medium">Medium Risk</option>
          <option value="High">High Risk</option>
        </select>

        <button className="clear-button" onClick={clearFilters}>
          Clear Filters
        </button>
      </div>

      <div className="applications-results">
        Showing <strong>{filteredApplications.length}</strong> of{" "}
        <strong>{applicationsData.length}</strong> applications
      </div>

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>APPLICATION ID</th>
              <th>APPLICANT</th>
              <th>TYPE</th>
              <th>LOAN AMOUNT</th>
              <th>STATUS</th>
              <th>RISK LEVEL</th>
              <th>ACTION</th>
            </tr>
          </thead>

          <tbody>
            {filteredApplications.length > 0 ? (
              filteredApplications.map((app) => (
                <tr key={app.id}>
                <td className="application-id">{app.id}</td>
                <td>{app.name}</td>
                <td>{app.property}</td>
                <td className="amount">{app.amount}</td>

                <td>
                  <span className={`status-badge ${app.status.toLowerCase().replace(" ", "-")}`}>
                    {app.status}
                  </span>
                </td>

                <td>
                  <span className={`risk-badge ${app.risk.toLowerCase()}`}>
                    {app.risk}
                  </span>
                </td>
                <td>
                  <NavLink
                  to={`/applications/${app.id}`}
                  className="detail-link">
                      View →
                  </NavLink>
                </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="7" className="empty-results">
                  No applications match your search.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </Layout>
  );
}

function ApplicationDetails() {
  const { id } = useParams();

  const application = applicationsData.find((app) => app.id === id);

  if (!application) {
    return (
      <Layout>
        <h1>Application Not Found</h1>
        <p>We couldn't find that application.</p>
        <NavLink to="/applications" className="detail-link">
          ← Back to Applications
        </NavLink>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="applications-header">
        <div>
          <h1>Application Details</h1>
          <p>Review the information for this loan application.</p>
        </div>

        <NavLink to="/applications" className="detail-link">
          ← Back to Applications
        </NavLink>
      </div>

      <div className="detail-card">
        <div className="detail-card-header">
          <div>
            <span className="application-id">{application.id}</span>
            <h2>{application.name}</h2>
          </div>

          <span
            className={`status-badge ${application.status
              .toLowerCase()
              .replace(" ", "-")}`}
          >
            {application.status}
          </span>
        </div>

        <div className="detail-grid">
          <div>
            <span>Applicant</span>
            <strong>{application.name}</strong>
          </div>

          <div>
            <span>Application ID</span>
            <strong>{application.id}</strong>
          </div>

          <div>
            <span>Property Type</span>
            <strong>{application.property}</strong>
          </div>

          <div>
            <span>Loan Amount</span>
            <strong>{application.amount}</strong>
          </div>

          <div>
            <span>Application Status</span>
            <strong>{application.status}</strong>
          </div>

          <div>
            <span>Risk Level</span>
            <strong>{application.risk}</strong>
          </div>
        </div>
      </div>
    </Layout>
  );
}



function AIAudit() {
  return (
    <Layout>
      <div className="applications-header">
        <div>
          <h1>AI Audit Console</h1>
          <p>Review AI-generated lending assessments and decision explanations.</p>
        </div>
      </div>

      <div className="detail-card">
        <h2>AI Assessment Overview</h2>
        <p>Example assessment for application APP-2026-001.</p>

        <div className="detail-grid">
          <div>
            <span>Application ID</span>
            <strong>APP-2026-001</strong>
          </div>
          <div>
            <span>AI Recommendation</span>
            <strong>Further Review</strong>
          </div>
          <div>
            <span>Risk Assessment</span>
            <strong>Low Risk</strong>
          </div>
          <div>
            <span>Assessment Status</span>
            <strong>Completed</strong>
          </div>
        </div>
      </div>

      <div className="detail-card">
        <h2>Decision Explanation</h2>
        <p>
          The example assessment indicates a low risk level. The application
          has been flagged for further review before a final lending decision.
        </p>
      </div>

      <div className="detail-card">
        <h2>Audit Information</h2>
        <div className="detail-grid">
          <div>
            <span>Assessment Type</span>
            <strong>Credit Risk Assessment</strong>
          </div>
          <div>
            <span>Review Status</span>
            <strong>Awaiting Human Review</strong>
          </div>
        </div>
      </div>
    </Layout>
  );
}


function StressTesting() {
  const scenarios = [
    {
      name: "Interest Rate Increase",
      description: "Simulates a rise in interest rates.",
      impact: "Higher monthly repayments",
      risk: "High",
    },
    {
      name: "Income Reduction",
      description: "Simulates a reduction in applicant income.",
      impact: "Reduced repayment capacity",
      risk: "Medium",
    },
    {
      name: "Property Value Decline",
      description: "Simulates a decrease in property value.",
      impact: "Higher loan-to-value ratio",
      risk: "Medium",
    },
  ];

  return (
    <Layout>
      <div className="applications-header">
        <div>
          <h1>Stress Testing</h1>
          <p>Explore example scenarios that may affect loan risk.</p>
        </div>
      </div>

      <div className="detail-card">
        <h2>Scenario Overview</h2>
        <p>
          These example scenarios demonstrate how changing financial
          conditions could affect a loan application.
        </p>

        <div className="stress-grid">
          {scenarios.map((scenario) => (
            <div className="stress-card" key={scenario.name}>
              <h3>{scenario.name}</h3>
              <p>{scenario.description}</p>

              <div className="stress-impact">
                <span>Potential impact</span>
                <strong>{scenario.impact}</strong>
              </div>

              <span className={`risk-badge ${scenario.risk.toLowerCase()}`}>
                {scenario.risk} Impact
              </span>
            </div>
          ))}
        </div>
      </div>

      <div className="detail-card">
        <h2>Testing Summary</h2>
        <p>
          The scenarios above are illustrative examples for the AL-Web
          prototype. They do not calculate actual financial outcomes.
        </p>
      </div>
    </Layout>
  );
}


function Approval() {
  const [selectedId, setSelectedId] = useState(applicationsData[0].id);
  const [decision, setDecision] = useState("Awaiting Decision");

  const application = applicationsData.find(
    (app) => app.id === selectedId
  );

  function makeDecision(newDecision) {
    setDecision(newDecision);
  }

  return (
    <Layout>
      <div className="applications-header">
        <div>
          <h1>Loan Approval</h1>
          <p>Review an application and record an underwriter decision.</p>
        </div>
      </div>

      <div className="detail-card">
        <h2>Select Application</h2>

        <select
          className="approval-select"
          value={selectedId}
          onChange={(e) => {
            setSelectedId(e.target.value);
            setDecision("Awaiting Decision");
          }}
        >
          {applicationsData.map((app) => (
            <option key={app.id} value={app.id}>
              {app.id} — {app.name}
            </option>
          ))}
        </select>

        {application && (
          <>
            <div className="detail-grid">
              <div>
                <span>Applicant</span>
                <strong>{application.name}</strong>
              </div>
              <div>
                <span>Application ID</span>
                <strong>{application.id}</strong>
              </div>
              <div>
                <span>Property Type</span>
                <strong>{application.property}</strong>
              </div>
              <div>
                <span>Loan Amount</span>
                <strong>{application.amount}</strong>
              </div>
              <div>
                <span>Current Status</span>
                <strong>{application.status}</strong>
              </div>
              <div>
                <span>Risk Level</span>
                <strong>{application.risk}</strong>
              </div>
            </div>

            <div className="approval-decision">
              <h2>Underwriter Decision</h2>
              <p>
                Current decision: <strong>{decision}</strong>
              </p>

              <div className="approval-actions">
                <button
                  className="approve-button"
                  onClick={() => makeDecision("Approved")}
                >
                  Approve
                </button>

                <button
                  className="reject-button"
                  onClick={() => makeDecision("Rejected")}
                >
                  Reject
                </button>
              </div>
            </div>
          </>
        )}
      </div>
    </Layout>
  );
}




function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/applications" element={<Applications />} />
        <Route path="/applications/:id" element={<ApplicationDetails />} />
        <Route path="/ai-audit" element={<AIAudit />} />
        <Route path="/stress-testing" element={<StressTesting />} />
        <Route path="/approval" element={<Approval />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
